/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package luigi.spizza;

/**
 *
 * Barry Molina, Kristen Klubertanz, Carlos Mayorga
 * ITDEV-110 Pizza App Week 9 Team Project
 */
public class LuigiSPizza {


    
    public static void main(String[] args)
    {
		Order o = new Order();
		o.takeOrder();
    }
    
}
