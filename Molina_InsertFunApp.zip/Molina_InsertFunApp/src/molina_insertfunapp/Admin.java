/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package molina_insertfunapp;

/**
 *
 * @author barrymolina
 * Barry Molina, ITDEV110-500, Assignment 6
 */
public class Admin {

	public void Intro() {

		System.out.println("This is the InsertFun app, where I prompt you");
		System.out.println("for certain types of words and then insert them");
		System.out.println("into a poem. Let's get started!");

	}
	public void goodbye() {
		System.out.println("That was fun! Goodbye.");
	}
}
